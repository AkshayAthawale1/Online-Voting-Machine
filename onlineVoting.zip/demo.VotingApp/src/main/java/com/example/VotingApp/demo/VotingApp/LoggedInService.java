//package com.example.VotingApp.demo.VotingApp;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//@Service
//public class LoggedInService {
//
//	@Autowired 
//	LoggedInUserRepo loggedInUserRepo;
//	
//	public void saveUser(LoggedInUsers loggedInUsers) {
//		loggedInUserRepo.save(loggedInUsers);
//		
//	}
//	
//	public String emailPresent() {
//		return loggedInUserRepo.findTopN();
//	}
//}

//package com.example.VotingApp.demo.VotingApp;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Query;
//import org.springframework.stereotype.Repository;
//
//@Repository
//public interface LoggedInUserRepo extends JpaRepository<LoggedInUsers, Integer>{
//
//	@Query(value = "SELECT email FROM user order by email ", nativeQuery = true)
//	public String findTopN();
//}
